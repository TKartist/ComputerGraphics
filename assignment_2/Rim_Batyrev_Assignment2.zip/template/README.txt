Completed:
ex1 to ex4

ex1 is completed in main.cpp file, please compile it to see the result as result.ppm.

To see the result of ex4, please run ./ex4_animation.sh on the terminal to execute the shell script and see the results as result.gif, result.mp4 etc.

Please read the Batyrev_Rim_Assignment2.pdf for written answers.